# Database Methods 5N0783 — Project Brief

**Project Assessment: 50% &nbsp;|&nbsp; Instructor: Joshua Aaron &nbsp;|&nbsp; Due Date: See Moodle**  
**Learning Outcomes: 1, 2, 3, 9, 10, 11**

---

## Overview

This project is yours to design. Your starting point is [Our World in Data](https://ourworldindata.org) — browse the site and find two datasets on a topic that genuinely interests you. One of them should have at least four fields so you have enough to work with. Use whatever import method suits you — loading from CSV, reading directly with pandas, importing from Excel, or anything else — and build your database around them.

There are 50 marks available across six parts. If you do the work described in each section and label things clearly so I can follow what you have done, the marks will follow. We will go through the project requirements in class and there will be plenty of time for questions — if you are unsure about anything, ask.

## What to Submit

Submit a single zipped folder to Moodle containing:

- Your Jupyter notebook (.ipynb file)
- An exported version (HTML or PDF — File > Download As)
- Your data files
- Any chart images saved from your visualisations

Use relative file paths so the notebook opens correctly on any computer.

---

## Part 1 — Introduction and Database Concepts
*QQI: Discussion | 5 marks | LO1, LO2*

**a) Introduction (2 marks)**
- Explain what your database is about and why a database is a good fit for this kind of information.
- Describe what you want to demonstrate in this project.

**b) Database concepts (2 marks)**
- Use at least four of the following terms correctly in context, showing you understand what they mean for your own database: table, record, field, primary key, foreign key, query, relationship, data type.

**c) Real-world examples (1 mark)**
- Mention a couple of real-world databases that are similar in purpose to yours.

---

## Part 2 — Database Design
*QQI: Design | 10 marks | LO9*

Describe the structure of your database before you start coding. This is your plan — it does not need to be perfect, but it should show you have thought things through.

**a) Table structure (3 marks)**
- Describe both tables: what fields each has and what data types are appropriate.
- Identify the primary key for each table.

**b) Relationship (3 marks)**
- Explain how the two tables connect — which field links them and what the relationship means.

**c) Data source (2 marks)**
- Explain which Our World in Data datasets you are using and what they contain.
- Confirm that your main table will have at least 15 rows.

**d) Query and form plan (2 marks)**
- Sketch out the queries you plan to write.
- List the fields your data entry form will use.

---

## Part 3 — Database Implementation
*QQI: Implementation | 10 marks | LO10*

**a) Create the database (3 marks)**
- Use CREATE TABLE to build both tables with appropriate field types.
- Set up the relationship between them.

**b) Load the data (4 marks)**
- Use both SQL INSERT INTO and pandas to_sql() to add records.
- Your main table needs at least 15 rows; populate your second table too.

**c) Verify (3 marks)**
- Confirm the data loaded correctly using SELECT and pd.read_sql().
- Label your cells so each step is easy to follow.

---

## Part 4 — Querying Your Database
*QQI: Design | 10 marks | LO3, LO10*

**a) SQL queries (4 marks)**
- Write at least three queries covering WHERE, ORDER BY, and specific column selection.
- Add a brief markdown cell before each one explaining what you were looking for.

**b) Pandas queries (3 marks)**
- Show the equivalent operations in pandas: boolean filtering, sort_values(), and column selection.

**c) Aggregation (3 marks)**
- Use GROUP BY in SQL and groupby() in pandas.
- Explain what the results tell you about your dataset.

---

## Part 5 — Interactive Form and Visualisation
*QQI: Implementation | 10 marks | LO10*

**a) Data entry form (5 marks)**
- Use at least two different widget types.
- The button callback should run INSERT INTO and call conn.commit().
- Show a confirmation message and clear the form after submission.

**b) Charts (5 marks)**
- Create at least two charts, each with a title and labelled axes.
- Write a sentence or two explaining what each chart shows.
- Save at least one chart to a file using savefig().

---

## Part 6 — Reflection and Documentation
*QQI: Documentation | 5 marks | LO11*

**a) Reflection (2 marks)**
- Describe one or two challenges you ran into and how you dealt with them.

**b) Further development (2 marks)**
- Suggest a few realistic ways the database could be extended or improved.

**c) Sources (1 mark)**
- List the class tutorials, documentation, classmates, and any other resources you used, with enough detail to find them again.

---

## Assessment Summary

| Part | Title | QQI Category | Marks |
|------|-------|-------------|------:|
| 1 | Introduction and Database Concepts | Discussion | 5 |
| 2 | Database Design | Design | 10 |
| 3 | Database Implementation | Implementation | 10 |
| 4 | Querying Your Database | Design | 10 |
| 5 | Interactive Form and Visualisation | Implementation | 10 |
| 6 | Reflection and Documentation | Documentation | 5 |
| | **Total** | | **50** |

*Design (20 marks) = Parts 2 and 4. Implementation (20 marks) = Parts 3 and 5.*
