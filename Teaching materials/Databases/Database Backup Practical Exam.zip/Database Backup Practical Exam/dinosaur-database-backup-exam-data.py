# import libraries
import numpy as np
import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
#import ipywidgets and display for forms
import ipywidgets as widgets
from IPython.display import display

# Create sample data for dinosaurs
# create a list of dictionaries
dino_data = [
    {'name': 'Tyrannosaurus Rex', 'family': 'Tyrannosauridae', 'period': 'Late Cretaceous', 'place_of_discovery': 'Montana', 'diet': 'Carnivore', 'length': 12, 'weight': 8000},
    {'name': 'Velociraptor', 'family': 'Dromaeosauridae', 'period': 'Late Cretaceous', 'place_of_discovery': 'Mongolia', 'diet': 'Carnivore', 'length': 2, 'weight': 15},
    {'name': 'Triceratops', 'family': 'Ceratopsidae', 'period': 'Late Cretaceous', 'place_of_discovery': 'North America', 'diet': 'Herbivore', 'length': 9, 'weight': 5000},
    {'name': 'Stegosaurus', 'family': 'Stegosauridae', 'period': 'Late Jurassic', 'place_of_discovery': 'North America', 'diet': 'Herbivore', 'length': 9, 'weight': 3500},
    {'name': 'Brachiosaurus', 'family': 'Brachiosauridae', 'period': 'Late Jurassic', 'place_of_discovery': 'North America', 'diet': 'Herbivore', 'length': 26, 'weight': 35000},
]

fossil_sites_data = [
    {'name': 'Hell Creek Formation', 'location': 'Montana', 'period': 'Late Cretaceous', 'area_sq_km': 1500, 'year_discovered': 1902},
    {'name': 'Morrison Formation', 'location': 'Colorado', 'period': 'Late Jurassic', 'area_sq_km': 1200, 'year_discovered': 1877},
    {'name': 'Nemegt Formation', 'location': 'Mongolia', 'period': 'Late Cretaceous', 'area_sq_km': 800, 'year_discovered': 1922},
    {'name': 'Dinosaur Provincial Park', 'location': 'Alberta', 'period': 'Late Cretaceous', 'area_sq_km': 80, 'year_discovered': 1955},
    {'name': 'Ischigualasto Formation', 'location': 'Argentina', 'period': 'Late Triassic', 'area_sq_km': 600, 'year_discovered': 1941},
]

# create a database from the list of dictionaries
df_dinosaurs = pd.DataFrame(dino_data)
df_fossil_sites = pd.DataFrame(fossil_sites_data)
# make a sql database from the dataframes

conn = sqlite3.connect('DinosaurDatabase.db')
df_dinosaurs.to_sql('dinosaurs', conn, if_exists='replace', index=False)
df_fossil_sites.to_sql('fossil_sites', conn, if_exists='replace', index=False)
# close the connection
conn.close()

# Create extended data for later use
dino_data_extended = [
    {'name': 'Ankylosaurus', 'family': 'Ankylosauridae', 'period': 'Late Cretaceous', 'place_of_discovery': 'Montana', 'diet': 'Herbivore', 'length': 8, 'weight': 3500},
    {'name': 'Diplodocus', 'family': 'Diplodocidae', 'period': 'Late Jurassic', 'place_of_discovery': 'Colorado', 'diet': 'Herbivore', 'length': 26, 'weight': 12000},
    {'name': 'Allosaurus', 'family': 'Allosauridae', 'period': 'Late Jurassic', 'place_of_discovery': 'Utah', 'diet': 'Carnivore', 'length': 8.5, 'weight': 2300},
    {'name': 'Parasaurolophus', 'family': 'Hadrosauridae', 'period': 'Late Cretaceous', 'place_of_discovery': 'Alberta', 'diet': 'Herbivore', 'length': 10, 'weight': 3500},
    {'name': 'Spinosaurus', 'family': 'Spinosauridae', 'period': 'Mid Cretaceous', 'place_of_discovery': 'Egypt', 'diet': 'Carnivore', 'length': 15, 'weight': 9000},
    {'name': 'Archaeopteryx', 'family': 'Archaeopterygidae', 'period': 'Late Jurassic', 'place_of_discovery': 'Germany', 'diet': 'Carnivore', 'length': 0.5, 'weight': 1},
    {'name': 'Compsognathus', 'family': 'Compsognathidae', 'period': 'Late Jurassic', 'place_of_discovery': 'Germany', 'diet': 'Carnivore', 'length': 1, 'weight': 3},
    {'name': 'Pachycephalosaurus', 'family': 'Pachycephalosauridae', 'period': 'Late Cretaceous', 'place_of_discovery': 'Montana', 'diet': 'Herbivore', 'length': 7, 'weight': 450},
    {'name': 'Baryonyx', 'family': 'Spinosauridae', 'period': 'Early Cretaceous', 'place_of_discovery': 'England', 'diet': 'Carnivore', 'length': 9, 'weight': 1700},
    {'name': 'Iguanodon', 'family': 'Iguanodontidae', 'period': 'Early Cretaceous', 'place_of_discovery': 'England', 'diet': 'Herbivore', 'length': 10, 'weight': 3500},
]

fossil_sites_extended = [
    {'name': 'Tendaguru Formation', 'location': 'Tanzania', 'period': 'Late Jurassic', 'area_sq_km': 1800, 'year_discovered': 1906},
    {'name': 'Yixian Formation', 'location': 'China', 'period': 'Early Cretaceous', 'area_sq_km': 3000, 'year_discovered': 1942},
    {'name': 'Bahariya Formation', 'location': 'Egypt', 'period': 'Mid Cretaceous', 'area_sq_km': 700, 'year_discovered': 1911},
    {'name': 'Solnhofen Limestone', 'location': 'Germany', 'period': 'Late Jurassic', 'area_sq_km': 100, 'year_discovered': 1861},
    {'name': 'Wessex Formation', 'location': 'England', 'period': 'Early Cretaceous', 'area_sq_km': 350, 'year_discovered': 1889},
    {'name': 'Judith River Formation', 'location': 'Montana', 'period': 'Late Cretaceous', 'area_sq_km': 1200, 'year_discovered': 1876},
    {'name': 'La Brea Tar Pits', 'location': 'California', 'period': 'Pleistocene', 'area_sq_km': 0.1, 'year_discovered': 1901},
    {'name': 'Ghost Ranch', 'location': 'New Mexico', 'period': 'Late Triassic', 'area_sq_km': 85, 'year_discovered': 1947},
    {'name': 'Cleveland-Lloyd Quarry', 'location': 'Utah', 'period': 'Late Jurassic', 'area_sq_km': 3, 'year_discovered': 1927},
]

# lets convert each of these to xls and csv files for later use
df_dino_extended = pd.DataFrame(dino_data_extended)
df_fossil_sites_extended = pd.DataFrame(fossil_sites_extended)
# convert to csv 
df_dino_extended.to_csv('dino_extended.csv', index=False)
df_dino_extended.to_excel('dino_extended.xlsx', index=False)
# convert to excel files
df_fossil_sites_extended.to_csv('fossil_sites_extended.csv', index=False)
df_fossil_sites_extended.to_excel('fossil_sites_extended.xlsx', index=False)